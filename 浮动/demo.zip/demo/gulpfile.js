var gulp= require('gulp');
var browserSync=require('browser-sync');
var reload = browserSync.reload;

gulp.task('browser-sync', function() {
    browserSync.init({
        server: {
            baseDir: './src',
        }
    });
});


gulp.task('default', ['browser-sync'], function() {
    // 观察改动
    gulp.watch([
        './src/index.html'
    ]).on('change', reload);

});